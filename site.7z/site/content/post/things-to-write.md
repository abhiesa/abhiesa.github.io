+++
title = "Why this blog is impossible ?"
description = "I want to write about lot of things, but, i lack the strength for writing. I know, I am lazy, Still projection is a good thing. And this is the best thing, i am good at. Another thing, where i am best, is thinking about the worse.I took a very long time, to start this blog. 7 + years, in the making. What made this delay is a lot of things, but most importantly the comfort. I was not comfortable with the blogging platforms, i didn't had control.I can't be online all the time, and working offline was almost impossible for blogspot, wordpress, tumbler etc. Believe it or not, i have tested all."
tags = [ "projection" ]
date = "2014-10-21T01:56:00+05:30"
categories = ["Blogging"]
keywords = ["Blogging", "projection"]
slug = "why-this-blog-is-impossible"
draft = false
+++
I want to write about lot of things, but, i lack the strength for writing. I know, I am lazy, Still projection is a good thing. And this is the best thing, i am good at. Another thing, where i am best, is thinking about the worse.
I took a very long time, to start this blog. 7 + years, in the making. What made this delay is a lot of things, but most importantly the comfort. I was not comfortable with the blogging platforms, i didn't had control.
I can't be online all the time, and working offline was almost impossible for blogspot, wordpress, tumbler etc. Believe it or not, i have tested all.

choose any blogging engine, and put subdomain abhiesa, in front of it, and i am there. But that was out of my comfort zone. Too many options in editing, and not having control on output, like css, js, html etc.

After my long patience, i moved to jkyll like system last year, and still, it was tough for me. Ruby, Rake, RVM, etc etc. Yes i am a nerd, but not for ruby, python, jade etc. Also, i needed my home laptop for doing anything on it. I was unable to write, at office (whenever i was free), on the move, at night (when my little daughter, goes to sleep, and illumination is another problem.), etc etc.

Recently i found out something called [Hexo.IO](http://hexo.io), and [Travis-CI](http://travis-ci.org), and i combined both of them.
Now I have tweaked theme, control over output generation, and automated builds. That means, i office i can just write something on notepad, and in evening, i can create a new file on github and paste its content it.
I can do the same thing from my Nexus 7, and my cheap Micromax Canvas phone.
Whenever I check in, I get my blog updated. I can always revert, and change anything a lot.

Still, somethings are left.
* learn markdown as pro
* optimize css
* move from ejs theme to handlebar theme
* optimize site for speed, currently speed is very bad
* have total control on output
* find a place to host images

I am using sublime text 3 for typing, this blog, most of the time.
I don't know right know, how good this setup is going to be, but for now, this looks ok, but still impossible.
